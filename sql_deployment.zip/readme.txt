Original project name: sql
Exported on: 05/06/2019 10:38:21
Exported by: ATTUNITY_LOCAL\Ori.Porat
